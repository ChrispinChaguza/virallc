# ViralLC: A package rapid assignment of viral lineage nomenclature

## Get the source code
```
git clone https://github.com/ChrispinChaguza/virallc.git
```

## About virallc

## Setup

### Installing using Pip

The easist way to install the latest version of ViralLC is using Pip
```
pip install virallc
```

Here is a command to install a specific version of ViralLC using Pip
```
pip install virallc==1.0.17
```

### Installing using Conda

Installation using Conda (upcoming!).
```
conda install -c conda-forge virallc
```

Or
```
conda install -c bioconda virallc
```

### Installing directly from Github

First, download ViralLC from GitHub and then manually setup the environment for the package 

```
git clone https://github.com/ChrispinChaguza/virallc.git
cd virallc
```

Second, manually install the required package dependencies (mafft, nextclade, biopython, blast, pandas, networkx, and gitdir) using Conda and Pip. If the installation fails, create a new Conda environment and then repeat the installation.

```
conda install -c bioconda mafft=7.526 -y
conda install -c conda-forge python=3.14.2 -y
conda install -c bioconda nextclade=3.18.1 -y
conda install -c conda-forge biopython=1.86 -y
conda install -c bioconda blast=2.16.0 -y
conda install -c conda-forge pandas=3.0.0 -y
conda install -c conda-forge networkx=3.6.1 -y
```

```
pip install gitdir==1.2.7
pip install build
```

Alternatively, the packages can be installed in a new Conda environment as shown below.
```
conda env create -n virallc -f environment.yml 
```

Follow the instructions below to build and install ViralLC
```
python -m build 
pip install --force-reinstall dist/{INSERT THE COMPILED SOFTWARE VERSION} 
```

## Basic usage

### Setting up database

When running virallc for the first time, it will automatically download and setup the virallc database in the home directory (~/viraldb/). However, if new lineages or sublineages have been assigned, you can redownload and update your local database as follows:

Here is a command to setup the database after installing the tool
```
virallc database --setupdb
```
Or
```
virallc database -s
```

Here is a command to update a database (if corrupt, not found in the local machine, etc.)
```
virallc database --updatedb
```
Or
```
virallc database -u
```

Here is a command to check version of the databases installed locally
```
virallc database --version
```
Or
```
virallc database -v
```

### Assigning lineages

The simplest way to run virallc is to provide a single or separate multiple input FASTA file containing a single or multiple rotavirus A sequences.
```
virallc assign --in input.fasta --out report.tsv --db dbname
```

Or
```
virallc assign -i input.fasta -o report.tsv -d dbname
```

To assign lineages to several sequences in a multi-FASTA file (each individual sequence represents a single strain):
```
virallc assign --in input1.fasta input2.fasta input3.fasta --out report.tsv --db dbname
```

Or
```
virallc assign -i input1.fasta input2.fasta input3.fasta -o report.tsv -d dbname
```

To include the sequence in the output:
```
virallc assign --in input1.fasta input2.fasta input3.fasta --out report.tsv --db dbname --seq
```

Or
```
virallc assign -i input1.fasta input2.fasta input3.fasta -o report.tsv -d dbname -s
```

To overwrite the output files:
```
virallc assign --in input1.fasta input2.fasta input3.fasta --out report.tsv --db dbname --seq --force
```

Or
```
virallc assign -i input1.fasta input2.fasta input3.fasta -o report.tsv -d dbname -s -f
```

To assign lineages faster using more CPUs/threads:
```
virallc assign --in input1.fasta input2.fasta input3.fasta --out report.tsv --db dbname --seq --threads 10
```

Or
```
virallc assign -i input1.fasta input2.fasta input3.fasta -o report.tsv -d dbname -s -t 10
```

To suppress the results on the terminal:
```
virallc assign --in input1.fasta input2.fasta input3.fasta --out report.tsv --db dbname --seq --threads 10 --quiet
```

Or
```
virallc assign -i input1.fasta input2.fasta input3.fasta -o report.tsv -d dbname -s -t 10 -q
```

### Example dataset (Rotavirus A)

Here is a command to assign rotavirus A lineages to samples in *example* directory
```
virallc assign -i example.fna -o report.tsv -d RotavirusA
```

### Software version

Run the command below to show the software version
```
virallc version
```

## Cite
To be updated!
