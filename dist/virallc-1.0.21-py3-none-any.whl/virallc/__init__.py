""" ViralLC: A package rapid assignment of viral lineage nomenclature"""

__version__ = "1.0.21"

