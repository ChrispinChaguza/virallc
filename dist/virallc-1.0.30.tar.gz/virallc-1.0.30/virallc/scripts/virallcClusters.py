#!/usr/bin/env python

import numpy as np
import pandas as pd
import os
import sys
import glob
import networkx as nx
import argparse

def lineages1Levels(cmdValues):

    snpDistDF = pd.read_csv(cmdValues["input"],delimiter="\t",header=0)

    Graph = nx.Graph()
    Graph.add_nodes_from(snpDistDF.seq2.to_list())
    Graph.add_nodes_from(snpDistDF.seq1.to_list())

    snpDistDF1 = snpDistDF[snpDistDF.pid >= cmdValues["thresholds"][0]]
    seqPair = [(snpDistDF1.seq1[i],snpDistDF1.seq2[i]) for i in snpDistDF1.index]

    Graph.add_edges_from(seqPair)
    networkClusters = tuple(nx.connected_components(Graph))

    fhandle = open(f"{cmdValues['output']}","w")

    for i,j in enumerate(networkClusters):
        for s in j:
            FirstLevelLin = str(i+1)
            seqLabel = s
            clusterPrefix = cmdValues["prefix"]
            separator = cmdValues["separator"]

            fhandle.write(f"{seqLabel}\t{clusterPrefix}{separator}{FirstLevelLin}\n")

    fhandle.close();

def lineages2Levels(cmdValues):
    snpDistDF = pd.read_csv(cmdValues["input"],delimiter="\t",header=0)

    Graph = nx.Graph()
    Graph.add_nodes_from(snpDistDF.seq2.to_list())
    Graph.add_nodes_from(snpDistDF.seq1.to_list())

    snpDistDF1 = snpDistDF[snpDistDF.pid >= cmdValues["thresholds"][0]]
    seqPair = [(snpDistDF1.seq1[i],snpDistDF1.seq2[i]) for i in snpDistDF1.index]

    Graph.add_edges_from(seqPair)
    networkClusters = tuple(nx.connected_components(Graph))

    fhandle = open(f"{cmdValues['output']}","w")

    for i,j in enumerate(networkClusters):
        snpDistDF2 = snpDistDF[snpDistDF.seq1.isin(j) & snpDistDF.seq2.isin(j)]
        snpDistDF3 = snpDistDF2[snpDistDF2.pid >= cmdValues["thresholds"][1]]

        Graph1 = nx.Graph()
        Graph1.add_nodes_from(j)

        seqPair1 = [(snpDistDF3.seq1[z],snpDistDF3.seq2[z]) for z in snpDistDF3.index]

        Graph1.add_edges_from(seqPair1)
        networkClusters1 = tuple(nx.connected_components(Graph1))

        for r,k in enumerate(networkClusters1):
            for s in k:
                FirstLevelLin = str(i+1)
                seqLabel = s
                SecondLevelLin = str(r+1)
                clusterPrefix = cmdValues["prefix"]
                separator = cmdValues["separator"]

                if len(networkClusters1)==1:
                   fhandle.write(f"{seqLabel}\t{clusterPrefix}{separator}{FirstLevelLin}\n")
                else:
                    fhandle.write(f"{seqLabel}\t{clusterPrefix}{separator}{FirstLevelLin}.{SecondLevelLin}\n")

    fhandle.close();

def lineages3Levels(cmdValues):
    snpDistDF = pd.read_csv(cmdValues["input"],delimiter="\t",header=0)

    Graph = nx.Graph()
    Graph.add_nodes_from(snpDistDF.seq2.to_list())
    Graph.add_nodes_from(snpDistDF.seq1.to_list())

    snpDistDF1 = snpDistDF[snpDistDF.pid >= cmdValues["thresholds"][0]]
    seqPair = [(snpDistDF1.seq1[i],snpDistDF1.seq2[i]) for i in snpDistDF1.index]

    Graph.add_edges_from(seqPair)
    networkClusters = tuple(nx.connected_components(Graph))

    fhandle = open(f"{cmdValues['output']}","w")

    for i,j in enumerate(networkClusters):
        snpDistDF2 = snpDistDF[snpDistDF.seq1.isin(j) & snpDistDF.seq2.isin(j)]
        snpDistDF3 = snpDistDF2[snpDistDF2.pid >= cmdValues["thresholds"][1]]

        Graph1 = nx.Graph()
        Graph1.add_nodes_from(j)

        seqPair1 = [(snpDistDF3.seq1[z],snpDistDF3.seq2[z]) for z in snpDistDF3.index]

        Graph1.add_edges_from(seqPair1)
        networkClusters1 = tuple(nx.connected_components(Graph1))

        for p,q in enumerate(networkClusters1):
            snpDistDF2R = snpDistDF[snpDistDF.seq1.isin(q) & snpDistDF.seq2.isin(q)]
            snpDistDF3R = snpDistDF2R[snpDistDF2R.pid >= cmdValues["thresholds"][2]]

            Graph2 = nx.Graph()
            Graph2.add_nodes_from(q)

            seqPair1R = [(snpDistDF3R.seq1[z],snpDistDF3R.seq2[z]) for z in snpDistDF3R.index]

            Graph2.add_edges_from(seqPair1R)
            networkClusters2 = tuple(nx.connected_components(Graph2))

            for r,k in enumerate(networkClusters2):
                for s in k:
                    FirstLevelLin = str(i+1)
                    SecondLevelLin = str(p+1)
                    ThirdLevelLin = str(r+1)
                    clusterPrefix = cmdValues["prefix"]
                    seqLabel = s
                    separator = cmdValues["separator"]

                    if len(networkClusters1)==1:
                        fhandle.write(f"{seqLabel}\t{clusterPrefix}{separator}{FirstLevelLin}\n")
                    else:
                        if len(networkClusters2)==1:
                            fhandle.write(f"{seqLabel}\t{clusterPrefix}{separator}{FirstLevelLin}.{SecondLevelLin}\n")
                        else:
                            fhandle.write(f"{seqLabel}\t{clusterPrefix}{separator}{FirstLevelLin}.{SecondLevelLin}.{ThirdLevelLin}\n")
                        
    fhandle.close();

def lineages4Levels(cmdValues):
    snpDistDF = pd.read_csv(cmdValues["input"],delimiter="\t",header=0)

    Graph = nx.Graph()
    Graph.add_nodes_from(snpDistDF.seq2.to_list())
    Graph.add_nodes_from(snpDistDF.seq1.to_list())

    snpDistDF1 = snpDistDF[snpDistDF.pid >= cmdValues["thresholds"][0]]
    seqPair = [(snpDistDF1.seq1[i],snpDistDF1.seq2[i]) for i in snpDistDF1.index]

    Graph.add_edges_from(seqPair)
    networkClusters = tuple(nx.connected_components(Graph))

    fhandle = open(f"{cmdValues['output']}","w")

    for i,j in enumerate(networkClusters):
        snpDistDF2 = snpDistDF[snpDistDF.seq1.isin(j) & snpDistDF.seq2.isin(j)]
        snpDistDF3 = snpDistDF2[snpDistDF2.pid >= cmdValues["thresholds"][1]]

        Graph1 = nx.Graph()
        Graph1.add_nodes_from(j)

        seqPair1 = [(snpDistDF3.seq1[z],snpDistDF3.seq2[z]) for z in snpDistDF3.index]

        Graph1.add_edges_from(seqPair1)
        networkClusters1 = tuple(nx.connected_components(Graph1))

        for p,q in enumerate(networkClusters1):
            snpDistDF2R = snpDistDF[snpDistDF.seq1.isin(q) & snpDistDF.seq2.isin(q)]
            snpDistDF3R = snpDistDF2R[snpDistDF2R.pid >= cmdValues["thresholds"][2]]

            Graph2 = nx.Graph()
            Graph2.add_nodes_from(q)

            seqPair1R = [(snpDistDF3R.seq1[z],snpDistDF3R.seq2[z]) for z in snpDistDF3R.index]

            Graph2.add_edges_from(seqPair1R)
            networkClusters2 = tuple(nx.connected_components(Graph2))

            for x,y in enumerate(networkClusters2):

                snpDistDF2RR = snpDistDF[snpDistDF.seq1.isin(y) & snpDistDF.seq2.isin(y)]
                snpDistDF3RR = snpDistDF2RR[snpDistDF2RR.pid >= cmdValues["thresholds"][3]]

                Graph3 = nx.Graph()
                Graph3.add_nodes_from(y)

                seqPair1RR = [(snpDistDF3RR.seq1[z],snpDistDF3RR.seq2[z]) for z in snpDistDF3RR.index]

                Graph3.add_edges_from(seqPair1RR)
                networkClusters3 = tuple(nx.connected_components(Graph3))

                for r,k in enumerate(networkClusters3):

                    for s in k:
                        FirstLevelLin = str(i+1)
                        SecondLevelLin = str(p+1)
                        ThirdLevelLin = str(x+1)
                        FourthLevelLin = str(r+1)
                        clusterPrefix = cmdValues["prefix"]
                        seqLabel = s
                        separator = cmdValues["separator"]

                        if len(networkClusters1)==1:
                            fhandle.write(f"{seqLabel}\t{clusterPrefix}{separator}{FirstLevelLin}\n")
                        else:
                            if len(networkClusters2)==1:
                                fhandle.write(f"{seqLabel}\t{clusterPrefix}{separator}{FirstLevelLin}.{SecondLevelLin}\n")
                            else:
                                if len(networkClusters3)==1:
                                    fhandle.write(f"{seqLabel}\t{clusterPrefix}{separator}{FirstLevelLin}.{SecondLevelLin}.{ThirdLevelLin}\n")
                                else:
                                    fhandle.write(f"{seqLabel}\t{clusterPrefix}{separator}{FirstLevelLin}.{SecondLevelLin}.{ThirdLevelLin}.{FourthLevelLin}\n")

    fhandle.close();

def main():
    version = "1.0.1"

    options=argparse.ArgumentParser(sys.argv[0],
                usage=argparse.SUPPRESS,
                description='virallcClusters: A tool for defining viral sequence clusters based on percent nucleotide identity of aligned samples',
                prefix_chars='-',
                add_help=True,
                epilog='Written by Chrispin Chaguza, St Jude Children\'s Research Hospital, 2025')

    options.add_argument('--input','-i',action='store',required=True,nargs=1,
                        metavar='input',dest='input',
                        help='Input file generated by alnPairDist')
    options.add_argument('--prefix','-p',action='store',required=True,nargs=1,
                        metavar='prefix',dest='prefix',
                        help='Cluster label prefix')
    options.add_argument('--out','-o',action='store',required=False,nargs=1,
                        metavar='outfile',dest='outfile',default="clusters.out.tsv",
                        help='Output file containing inferred sequence clusters')
    options.add_argument('--sep','-s',action='store',required=False,nargs=1,
                        metavar='separator',dest='separator',default="",
                        help='Lineage label separator')
    options.add_argument('--thresholds','-t',action='store',required=True,nargs="*",
                        metavar='thresholds',dest='thresholds',
                        help='Cluster or lineage thresholds')
    options.add_argument('--version','-v',action='store_true',default=False,
                        dest='version',help='Show software version')

    if len(sys.argv[:])>1:
        if sys.argv[1]=="-v" or sys.argv[1]=="--version":
            print(f"virallcClusters {version}")
            sys.exit()
        else:
            options=options.parse_args(args=None if sys.argv[2:] else ['--help'])
    else:
        options=options.parse_args(args=None if sys.argv[2:] else ['--help'])

    cmdValues = {'input': options.input[0:][0],
                 'prefix': options.prefix[0:][0],
                 'output': options.outfile[0:][0] if isinstance(options.outfile,list) else options.outfile,
                 'separator': options.separator[0:][0] if isinstance(options.separator,list) else options.separator,
                 'thresholds': [float(i) for i in options.thresholds[0:]] if isinstance(options.thresholds,list) else options.thresholds,
                 'version': options.version}

    if len(cmdValues['thresholds'])==1:
        lineages1Levels(cmdValues)
    elif len(cmdValues['thresholds'])==2:
        lineages2Levels(cmdValues)
    elif len(cmdValues['thresholds'])==3:
        lineages3Levels(cmdValues)
    elif len(cmdValues['thresholds'])==4:
        lineages4Levels(cmdValues)
    else:
        pass

if __name__=="__main__":
    main()



